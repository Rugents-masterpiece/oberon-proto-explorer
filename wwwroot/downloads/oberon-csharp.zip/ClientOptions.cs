internal sealed record ClientOptions(string Host, int Port)
{
    public static ClientOptions Parse(string[] args)
    {
        string host = "192.168.16.169";
        int port = 21008;
        for (int i = 0; i < args.Length; i += 2)
        {
            if (i + 1 >= args.Length) throw new ArgumentException("Missing option value");
            string value = args[i + 1];
            switch (args[i])
            {
                case "--host":
                    if (!System.Text.RegularExpressions.Regex.IsMatch(value, @"\A[A-Za-z0-9._-]+\z"))
                        throw new ArgumentException("Host must be a DNS name or IPv4 address (no scheme or port)");
                    host = value;
                    break;
                case "--port":
                    if (!System.Text.RegularExpressions.Regex.IsMatch(value, @"\A[0-9]+\z") ||
                        !int.TryParse(value, out port) || port < 1 || port > 65535)
                        throw new ArgumentException("Port must be an integer from 1 to 65535");
                    break;
                default: throw new ArgumentException("Unknown option: " + args[i]);
            }
        }
        return new(host, port);
    }
}
