using System.Text.Json;
using Exa.OBERON.ServiceGateway.Contracts;
using Google.Protobuf.Reflection;

// Offline reflection over the generated contract. No channel, login or RPC calls.
internal static class Inventory
{
    internal static void Export(string path)
    {
        var file = PingRequest.Descriptor.File;
        var messages = new Dictionary<string, object>();
        var enums = new Dictionary<string, object>();
        void AddEnum(EnumDescriptor descriptor) => enums[descriptor.FullName] = new
        {
            values = descriptor.Values.Select(v => new { name = v.Name, number = v.Number })
        };
        void AddMessage(MessageDescriptor descriptor)
        {
            messages[descriptor.FullName] = new
            {
                map_entry = descriptor.ToProto().Options?.MapEntry ?? false,
                fields = descriptor.Fields.InDeclarationOrder().Select(f => new
                {
                    name = f.Name,
                    json_name = f.JsonName,
                    number = f.FieldNumber,
                    type = f.FieldType == FieldType.Message ? f.MessageType.FullName
                        : f.FieldType == FieldType.Enum ? f.EnumType.FullName : f.FieldType.ToString().ToLowerInvariant(),
                    cardinality = f.IsRepeated ? "repeated" : f.IsRequired ? "required" : "optional",
                    proto3_optional = f.ToProto().Proto3Optional,
                    oneof = f.ContainingOneof?.Name
                })
            };
            foreach (var nested in descriptor.NestedTypes) AddMessage(nested);
            foreach (var nested in descriptor.EnumTypes) AddEnum(nested);
        }
        foreach (var descriptor in file.MessageTypes) AddMessage(descriptor);
        foreach (var descriptor in file.EnumTypes) AddEnum(descriptor);
        var inventory = new
        {
            services = file.Services.Select(s => new
            {
                name = s.FullName,
                methods = s.Methods.Select(m => new
                {
                    name = m.Name, path = $"/{s.FullName}/{m.Name}",
                    input = m.InputType.FullName, output = m.OutputType.FullName,
                    client_streaming = m.IsClientStreaming, server_streaming = m.IsServerStreaming
                })
            }),
            messages, enums
        };
        File.WriteAllText(path, JsonSerializer.Serialize(inventory, new JsonSerializerOptions { WriteIndented = true }));
    }
}
