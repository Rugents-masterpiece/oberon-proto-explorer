using Exa.OBERON.ServiceGateway.Contracts;
using Grpc.Core;
using Grpc.Net.Client;

internal static class Program
{
    private static async Task<int> Main(string[] args)
    {
        try
        {
            if (args.Length == 2 && args[0] == "--export-inventory")
            {
                Inventory.Export(args[1]); // Offline; no channel or server calls.
                return 0;
            }
            if (args.SequenceEqual(new[] { "--self-test" }))
            {
                SelfTests.Run(); // No channel and no server calls.
                return 0;
            }
            var options = ClientOptions.Parse(args);
            using var channel = GrpcChannel.ForAddress($"http://{options.Host}:{options.Port}");
            var client = new OBERONServiceGRPC.OBERONServiceGRPCClient(channel);
            using var call = client.PingAsync(new PingRequest { Message = "hello" },
                deadline: DateTime.UtcNow.AddSeconds(10));
            var response = await call.ResponseAsync;
            Console.WriteLine($"Ping -> {response.Message}");
            return 0;
        }
        catch (ArgumentException error)
        {
            Console.Error.WriteLine($"Arguments: {error.Message}");
            Console.Error.WriteLine("Usage: dotnet run -- [--host DNS-or-IPv4] [--port 1..65535]");
            return 2;
        }
        catch (RpcException error)
        {
            Console.Error.WriteLine($"gRPC error: {error.StatusCode}: {error.Status.Detail}");
            return 1;
        }
    }
}
