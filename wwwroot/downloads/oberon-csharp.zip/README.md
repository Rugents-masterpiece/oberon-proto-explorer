# OBERON Ping — C#

Samostatný C# klient pre bezpečný test dostupnosti OBERON ServiceGateway pomocou jediného RPC Ping.

## Predpoklady

.NET SDK 10 (cieľ net10.0), prístup k NuGet a k serveru cez dôveryhodnú LAN.

Balík musí obsahovať autoritatívny súbor `proto/oberon_service_grpc.proto`; nekopírujte kontrakt zo starých príkladov. Všetky nasledujúce príkazy sú relatívne ku koreňu rozbaleného balíka.

## Obnova závislostí

Príkaz spustite v koreňovom priečinku rozbaleného balíka.

```sh
dotnet restore PingClient.csproj
```

## Generovanie a zostavenie

Grpc.Tools počas zostavenia spracuje proto/oberon_service_grpc.proto. Kód vznikne v obj/, namespace je Exa.OBERON.ServiceGateway.Contracts.

```sh
dotnet build PingClient.csproj --no-restore
```

## Offline testy

Režim --self-test nekontaktuje server a nevytvorí kanál.

```sh
dotnet run --project PingClient.csproj --no-build -- --self-test
```

## Offline export RPC a atribútov

Stačí .NET SDK a existujúce NuGet závislosti; ďalší jazykový runtime nie je potrebný.
`Inventory.cs` používa generované descriptory Google.Protobuf a System.Text.Json.
Export obsahuje služby, metódy, typy vstupov/výstupov, všetky polia a enum hodnoty.
Režim nevytvorí kanál a nekontaktuje server. Zdrojové komentáre runtime descriptor neobsahuje.

```sh
dotnet run --project PingClient.csproj -- --export-inventory rpc-inventory.json
```

## Ping

Očakávaná úspešná odpoveď má tvar Ping -> pong. Ide o vysvetlenie, nie o záznam aktuálneho behu.

```sh
dotnet run --project PingClient.csproj --no-build -- --host 192.168.16.169 --port 21008
```

## Poznámky

- Ide o natívne gRPC cez HTTP/2. Tento klient nie je určený pre prehliadač; prehliadač potrebuje gRPC-Web a kompatibilný server alebo proxy.
- Ukážka používa nešifrované spojenie (plaintext), iba v dôveryhodnej LAN. Mimo nej nakonfigurujte TLS a overovanie certifikátu.
- Ping nevyžaduje prihlásenie. Klient posiela iba Ping, má deadline 10 sekúnd a po skončení zatvorí kanál.
- Pri budúcom rozšírení autentifikácie zavolajte GetLoginSalts s username. Pre dostupné backendy vypočítajte SHA1(salt + password) z bajtov Windows-1250 (cp1250), ako hexadecimálny reťazec. Do LoginUser vložte gen1PasswordHash, gen2PasswordHash a prípadne cashRegisterGen2PasswordHash podľa príslušných saltov. Skontrolujte result; sessionId odošlite v metadata s kľúčom userdata. Tajomstvá a sessionId nelogujte. Táto ukážka autentifikáciu nevykonáva.
- Host zadávajte ako DNS názov alebo IPv4 adresu bez http:// a bez portu; port je samostatné --port číslo 1 až 65535. Predvolené hodnoty sú 192.168.16.169 a 21008.
- Pri opakovanom testovaní ponechajte medzi volaniami aspoň 5 sekúnd. Úspešný Ping neoveruje autentifikáciu ani obchodné operácie.

V balíku nie sú vygenerované moduly, node_modules ani binárne závislosti; vzniknú lokálne počas prípravy.
