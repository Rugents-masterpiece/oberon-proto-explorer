internal static class SelfTests
{
    public static void Run()
    {
        var defaults = ClientOptions.Parse([]);
        if (defaults.Host != "192.168.16.169" || defaults.Port != 21008)
            throw new Exception("defaults failed");
        Console.WriteLine("Offline tests: PASS (defaults)");
        var explicitOptions = ClientOptions.Parse(["--host", "localhost", "--port", "12345"]);
        if (explicitOptions.Host != "localhost" || explicitOptions.Port != 12345)
            throw new Exception("explicit host and port failed");
        foreach (var invalid in new string[][] {
            ["--port", "0"], ["--port", "65536"], ["--port", "1.5"],
            ["--host", ""], ["--host", "http://localhost"], ["--unknown"], ["--port"] })
        {
            bool rejected = false;
            try { ClientOptions.Parse(invalid); }
            catch (ArgumentException) { rejected = true; }
            if (!rejected) throw new Exception("invalid arguments accepted");
        }
        Console.WriteLine("Offline tests: PASS (explicit host/port; 7 invalid argument cases)");
        var path = Path.GetTempFileName();
        try
        {
            Inventory.Export(path);
            using var document = System.Text.Json.JsonDocument.Parse(File.ReadAllText(path));
            var root = document.RootElement;
            if (root.GetProperty("services")[0].GetProperty("methods").GetArrayLength() != 103)
                throw new Exception("RPC inventory count failed");
            if (root.GetProperty("messages").EnumerateObject().Count() != 281)
                throw new Exception("message inventory count failed");
            var payload = root.GetProperty("messages").GetProperty("oberon.servicegateway.G1ProcedureCallRequest").GetProperty("fields")[1];
            if (payload.GetProperty("name").GetString() != "json_payload" ||
                payload.GetProperty("json_name").GetString() != "jsonPayload")
                throw new Exception("proto/JSON field names failed");
            Console.WriteLine("Offline tests: PASS (native inventory)");
        }
        finally { File.Delete(path); }
    }
}
