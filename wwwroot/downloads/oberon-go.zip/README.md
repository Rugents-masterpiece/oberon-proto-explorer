# OBERON Go Ping klient

Samostatný štartovací klient Go pre bezpečný test dostupnosti OBERON ServiceGateway: jedno volanie Ping bez hesla a bez zmien údajov.

## Predpoklady

Potrebujete Go 1.23 alebo novšie, protoc 29.3 a POSIX shell (na Windows napríklad WSL). Generátory sa nainštalujú lokálne do tools/. Potrebujete sieťový prístup na gRPC server a internet pri prvom zostavení. Všetky príkazy spúšťajte z koreňa rozbaleného balíka.

## Overte nástroje

Potrebujete Go 1.23 alebo novšie, protoc 29.3 a POSIX shell (na Windows napríklad WSL). Generátory sa nainštalujú lokálne do tools/.

```sh
go version
protoc --version
```

## Vygenerujte klienta

Súbor proto/oberon_service_grpc.proto je súčasťou ZIP. Proto nemá go_package, preto generate.sh používa M mapovanie pre oba generátory na example.com/oberon-client/pb. Výsledné zdroje sú v pb/.

```sh
sh generate.sh
```

## Zostavte a spustite offline testy

Pripnuté verzie sú v go.mod a kontrolné súčty v go.sum. Testy overujú argumenty bez siete.

```sh
go mod download
go test -mod=readonly ./...
go build -mod=readonly -o oberon-ping .
```

## Offline export RPC katalógu do JSON

Po vygenerovaní protobuf zdrojov exportujte úplný katalóg bez pripojenia k serveru:

```sh
sh generate.sh
go run ./cmd/inventory > rpc-inventory.json
```

Výstup `rpc-inventory.json` obsahuje `services` (názov služby a metódy s cestou `/služba/metóda`, vstupom, výstupom a streaming príznakmi), `messages` a `enums`. Typy správ a enumov majú plne kvalifikované názvy bez úvodnej bodky; primitívne typy používajú proto názvy (`int64`, `string`, …). Pri každom poli sú `name`, `json_name`, `number`, `type`, `cardinality`, `proto3_optional` a `oneof` (názov alebo `null`). Export zahŕňa vnorené správy, enumy a syntetické map-entry správy s `map_entry`.

Export číta iba vygenerované runtime protobuf deskriptory. **Zdrojové komentáre v nich nie sú dostupné a export ich nedopĺňa ani nevymýšľa.** Nevykonáva RPC, nepoužíva prihlasovacie údaje a nepotrebuje Python ani ďalšie knižnice. Prvá generácia/zostavenie môže potrebovať internet na stiahnutie existujúcich závislostí; samotný export po zostavení pracuje offline.

Offline testy pokrývajú katalóg (103 metód, 281 správ a 1 enum pre priložené proto), `json_payload` (`number=2`, `type=string`, `json_name=jsonPayload`), vnorené typy, mapy, oneof, proto3 optional, proto2 required a streaming. Podrobnosti overenia sú v `native-export-verification.md`.

## Zavolajte iba Ping

Argumenty sú host a port. Bez argumentov sa použije 192.168.16.169:21008. Timeout je 10 sekúnd; spojenie sa vždy zatvorí. Pri opakovaných živých volaniach počkajte aspoň 5 sekúnd.

```sh
./oberon-ping 192.168.16.169 21008
```

## Transport a bezpečnosť

Spojenie je plaintext bez TLS. Používajte iba dôveryhodnú LAN; neposielajte prihlasovacie údaje cez nedôveryhodnú sieť. Ping je bez prihlásenia; úspešný Ping nedokazuje funkčnosť autentifikácie ani podnikových procedúr.

Toto je natívny serverový gRPC klient cez HTTP/2, nie grpc-web pre prehliadač. Prehliadač potrebuje grpc-web klienta a kompatibilnú bránu/proxy; port 21008 je tu overený pre natívny gRPC.

## Prihlásenie pri budúcom rozšírení

Autentifikácia (iba vysvetlenie, tento klient ju nevykonáva): zavolajte GetLoginSalts s používateľským menom, pre každý dostupný backend vypočítajte SHA1 zo spojenia salt + heslo zakódovaného vo Windows-1250 a pošlite hexadecimálny hash do príslušného poľa LoginUser. Overte result; úspešné session_id posielajte v metadátach userdata pri ďalších RPC. Heslo, hash ani session_id nevypisujte a neukladajte do zdrojov.

Klient vykonáva výhradne Ping. Žiadne prihlasovanie ani mutácie nie sú implementované. Návratové kódy: 0 úspech, 2 neplatné argumenty, 1 chyba RPC.
