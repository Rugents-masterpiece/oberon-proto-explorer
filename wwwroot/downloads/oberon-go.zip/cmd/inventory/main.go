// Command inventory exports generated protobuf descriptors without contacting a server.
package main

import (
	"encoding/json"
	"fmt"
	"os"

	pb "example.com/oberon-client/pb"
	"google.golang.org/protobuf/reflect/protoreflect"
)

type catalog struct {
	Services []service              `json:"services"`
	Messages map[string]message     `json:"messages"`
	Enums    map[string]enumeration `json:"enums"`
}
type service struct {
	Name    string   `json:"name"`
	Methods []method `json:"methods"`
}
type method struct {
	Name            string `json:"name"`
	Path            string `json:"path"`
	Input           string `json:"input"`
	Output          string `json:"output"`
	ClientStreaming bool   `json:"client_streaming"`
	ServerStreaming bool   `json:"server_streaming"`
}
type message struct {
	Fields   []field `json:"fields"`
	MapEntry bool    `json:"map_entry"`
}
type field struct {
	Name           string  `json:"name"`
	JSONName       string  `json:"json_name"`
	Number         int32   `json:"number"`
	Type           string  `json:"type"`
	Cardinality    string  `json:"cardinality"`
	Proto3Optional bool    `json:"proto3_optional"`
	Oneof          *string `json:"oneof"`
}
type enumeration struct {
	Values []enumValue `json:"values"`
}
type enumValue struct {
	Name   string `json:"name"`
	Number int32  `json:"number"`
}

func inventory(file protoreflect.FileDescriptor) catalog {
	result := catalog{Services: []service{}, Messages: map[string]message{}, Enums: map[string]enumeration{}}
	for i := 0; i < file.Services().Len(); i++ {
		s := file.Services().Get(i)
		entry := service{Name: string(s.FullName()), Methods: []method{}}
		for j := 0; j < s.Methods().Len(); j++ {
			m := s.Methods().Get(j)
			entry.Methods = append(entry.Methods, method{string(m.Name()), "/" + string(s.FullName()) + "/" + string(m.Name()), string(m.Input().FullName()), string(m.Output().FullName()), m.IsStreamingClient(), m.IsStreamingServer()})
		}
		result.Services = append(result.Services, entry)
	}
	result.messages(file.Messages())
	result.enums(file.Enums())
	return result
}

func (c *catalog) messages(descriptors protoreflect.MessageDescriptors) {
	for i := 0; i < descriptors.Len(); i++ {
		m := descriptors.Get(i)
		entry := message{Fields: []field{}, MapEntry: m.IsMapEntry()}
		for j := 0; j < m.Fields().Len(); j++ {
			f := m.Fields().Get(j)
			kind := f.Kind().String()
			if f.Message() != nil {
				kind = string(f.Message().FullName())
			}
			if f.Enum() != nil {
				kind = string(f.Enum().FullName())
			}
			var oneof *string
			if o := f.ContainingOneof(); o != nil {
				name := string(o.Name())
				oneof = &name
			}
			entry.Fields = append(entry.Fields, field{string(f.Name()), f.JSONName(), int32(f.Number()), kind, f.Cardinality().String(), f.Syntax() == protoreflect.Proto3 && f.HasOptionalKeyword(), oneof})
		}
		c.Messages[string(m.FullName())] = entry
		c.messages(m.Messages())
		c.enums(m.Enums())
	}
}

func (c *catalog) enums(descriptors protoreflect.EnumDescriptors) {
	for i := 0; i < descriptors.Len(); i++ {
		e := descriptors.Get(i)
		entry := enumeration{Values: []enumValue{}}
		for j := 0; j < e.Values().Len(); j++ {
			v := e.Values().Get(j)
			entry.Values = append(entry.Values, enumValue{string(v.Name()), int32(v.Number())})
		}
		c.Enums[string(e.FullName())] = entry
	}
}

func main() {
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(inventory(pb.File_oberon_service_grpc_proto)); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
