package main

import (
	"encoding/json"
	"google.golang.org/protobuf/encoding/prototext"
	"google.golang.org/protobuf/reflect/protodesc"
	"google.golang.org/protobuf/types/descriptorpb"
	"testing"
)

func TestNestedDescriptorsAndPresence(t *testing.T) {
	var proto descriptorpb.FileDescriptorProto
	err := prototext.Unmarshal([]byte(`name:"fixture.proto" package:"fixture" syntax:"proto3"
 message_type { name:"Outer"
  oneof_decl {name:"choice"} oneof_decl {name:"_optional_text"}
  field {name:"text" number:1 type:TYPE_STRING label:LABEL_OPTIONAL oneof_index:0}
  field {name:"optional_text" number:2 type:TYPE_STRING label:LABEL_OPTIONAL oneof_index:1 proto3_optional:true}
  field {name:"entries" number:3 type:TYPE_MESSAGE type_name:".fixture.Outer.EntriesEntry" label:LABEL_REPEATED}
  field {name:"state" number:4 type:TYPE_ENUM type_name:".fixture.Outer.State" label:LABEL_OPTIONAL}
  nested_type {name:"EntriesEntry" options {map_entry:true}
   field {name:"key" number:1 type:TYPE_STRING label:LABEL_OPTIONAL}
   field {name:"value" number:2 type:TYPE_INT64 label:LABEL_OPTIONAL}}
  enum_type {name:"State" value {name:"UNKNOWN" number:0} value {name:"NEGATIVE" number:-1}}
 }
 service {name:"Stream" method {name:"Chat" input_type:".fixture.Outer" output_type:".fixture.Outer" client_streaming:true server_streaming:true}}`), &proto)
	if err != nil {
		t.Fatal(err)
	}
	file, err := protodesc.NewFile(&proto, nil)
	if err != nil {
		t.Fatal(err)
	}
	c := inventory(file)
	if len(c.Messages) != 2 || len(c.Enums) != 1 || !c.Messages["fixture.Outer.EntriesEntry"].MapEntry {
		t.Fatalf("nested descriptor traversal failed: %+v", c)
	}
	fields := c.Messages["fixture.Outer"].Fields
	if fields[0].Oneof == nil || *fields[0].Oneof != "choice" || fields[0].Proto3Optional {
		t.Fatal("real oneof incorrect")
	}
	if !fields[1].Proto3Optional || fields[1].Oneof == nil || *fields[1].Oneof != "_optional_text" || fields[1].JSONName != "optionalText" {
		t.Fatal("proto3 optional incorrect")
	}
	if fields[2].Type != "fixture.Outer.EntriesEntry" || fields[2].Cardinality != "repeated" || fields[2].Oneof != nil {
		t.Fatal("map field incorrect")
	}
	if fields[3].Type != "fixture.Outer.State" || c.Enums["fixture.Outer.State"].Values[1].Number != -1 {
		t.Fatal("nested enum incorrect")
	}
	m := c.Services[0].Methods[0]
	if !m.ClientStreaming || !m.ServerStreaming || m.Path != "/fixture.Stream/Chat" {
		t.Fatal("streaming method incorrect")
	}
	data, err := json.Marshal(c)
	if err != nil || !json.Valid(data) {
		t.Fatal("invalid JSON")
	}
}

func TestProto2RequiredCardinality(t *testing.T) {
	var proto descriptorpb.FileDescriptorProto
	if err := prototext.Unmarshal([]byte(`name:"required.proto" package:"fixture" syntax:"proto2" message_type {name:"Required" field {name:"id" number:1 type:TYPE_INT64 label:LABEL_REQUIRED}}`), &proto); err != nil {
		t.Fatal(err)
	}
	file, err := protodesc.NewFile(&proto, nil)
	if err != nil {
		t.Fatal(err)
	}
	f := inventory(file).Messages["fixture.Required"].Fields[0]
	if f.Cardinality != "required" || f.Type != "int64" || f.Proto3Optional {
		t.Fatalf("required field: %+v", f)
	}
}
