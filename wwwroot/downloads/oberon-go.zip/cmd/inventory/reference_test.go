package main

import (
	"encoding/json"
	pb "example.com/oberon-client/pb"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/descriptorpb"
	"os"
	"reflect"
	"strings"
	"testing"
)

// Optional acceptance test compares every field to a separately produced protoc
// descriptor set and both language outputs. Normal kit tests do not need protoc.
func TestProtocReferenceAndNativeOutputs(t *testing.T) {
	path := os.Getenv("INVENTORY_REFERENCE")
	if path == "" {
		t.Skip("set INVENTORY_REFERENCE to protoc descriptor set for acceptance")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var set descriptorpb.FileDescriptorSet
	if err := proto.Unmarshal(data, &set); err != nil {
		t.Fatal(err)
	}
	expected := catalog{Services: []service{}, Messages: map[string]message{}, Enums: map[string]enumeration{}}
	var addEnums func(string, []*descriptorpb.EnumDescriptorProto)
	addEnums = func(prefix string, enums []*descriptorpb.EnumDescriptorProto) {
		for _, e := range enums {
			v := enumeration{Values: []enumValue{}}
			for _, value := range e.Value {
				v.Values = append(v.Values, enumValue{value.GetName(), value.GetNumber()})
			}
			expected.Enums[prefix+"."+e.GetName()] = v
		}
	}
	var addMessages func(string, []*descriptorpb.DescriptorProto)
	addMessages = func(prefix string, messages []*descriptorpb.DescriptorProto) {
		for _, m := range messages {
			name := prefix + "." + m.GetName()
			entry := message{Fields: []field{}, MapEntry: m.GetOptions().GetMapEntry()}
			for _, f := range m.Field {
				kind := strings.ToLower(strings.TrimPrefix(f.GetType().String(), "TYPE_"))
				if f.GetTypeName() != "" {
					kind = strings.TrimPrefix(f.GetTypeName(), ".")
				}
				var oneof *string
				if f.OneofIndex != nil {
					n := m.OneofDecl[f.GetOneofIndex()].GetName()
					oneof = &n
				}
				entry.Fields = append(entry.Fields, field{f.GetName(), f.GetJsonName(), f.GetNumber(), kind, strings.ToLower(strings.TrimPrefix(f.GetLabel().String(), "LABEL_")), f.GetProto3Optional(), oneof})
			}
			expected.Messages[name] = entry
			addMessages(name, m.NestedType)
			addEnums(name, m.EnumType)
		}
	}
	for _, f := range set.File {
		if f.GetName() != "oberon_service_grpc.proto" {
			continue
		}
		addMessages(f.GetPackage(), f.MessageType)
		addEnums(f.GetPackage(), f.EnumType)
		for _, s := range f.Service {
			name := f.GetPackage() + "." + s.GetName()
			entry := service{Name: name, Methods: []method{}}
			for _, m := range s.Method {
				entry.Methods = append(entry.Methods, method{m.GetName(), "/" + name + "/" + m.GetName(), strings.TrimPrefix(m.GetInputType(), "."), strings.TrimPrefix(m.GetOutputType(), "."), m.GetClientStreaming(), m.GetServerStreaming()})
			}
			expected.Services = append(expected.Services, entry)
		}
	}
	actual := inventory(pb.File_oberon_service_grpc_proto)
	if !reflect.DeepEqual(expected, actual) {
		t.Fatal("Go generated runtime catalog differs from independent protoc reference")
	}
	for _, variable := range []string{"JAVA_INVENTORY_JSON", "GO_INVENTORY_JSON"} {
		path := os.Getenv(variable)
		if path == "" {
			t.Fatalf("%s is required for cross-language acceptance", variable)
		}
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		var decoded catalog
		if err := json.Unmarshal(data, &decoded); err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(expected, decoded) {
			t.Fatalf("%s differs from independent protoc reference", variable)
		}
	}
	maps, fields, methods := 0, 0, 0
	for _, m := range expected.Messages {
		fields += len(m.Fields)
		if m.MapEntry {
			maps++
		}
	}
	for _, s := range expected.Services {
		methods += len(s.Methods)
	}
	t.Logf("ALL native outputs equal protoc: methods=%d messages=%d fields=%d enums=%d map_entries=%d", methods, len(expected.Messages), fields, len(expected.Enums), maps)
}
