#!/bin/sh
set -eu
# Run from the extracted kit root. protoc 29.3 must be on PATH.
mkdir -p tools pb
GOBIN="$(pwd)/tools" go install google.golang.org/protobuf/cmd/protoc-gen-go@v1.36.5
GOBIN="$(pwd)/tools" go install google.golang.org/grpc/cmd/protoc-gen-go-grpc@v1.5.1
PATH="$(pwd)/tools:$PATH" protoc -I proto \
  --go_out=pb --go_opt=paths=source_relative \
  --go_opt=Moberon_service_grpc.proto=example.com/oberon-client/pb \
  --go-grpc_out=pb --go-grpc_opt=paths=source_relative \
  --go-grpc_opt=Moberon_service_grpc.proto=example.com/oberon-client/pb \
  proto/oberon_service_grpc.proto
