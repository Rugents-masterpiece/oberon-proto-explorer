package main

import (
	"encoding/json"
	"os/exec"
	"testing"
)

func TestOfflineInventoryCommand(t *testing.T) {
	data, err := exec.Command("go", "run", "./cmd/inventory").Output()
	if err != nil {
		t.Fatalf("native offline inventory command failed: %v", err)
	}
	var catalog struct {
		Services []struct {
			Name    string
			Methods []struct {
				Name, Path, Input, Output string
				ClientStreaming           bool `json:"client_streaming"`
				ServerStreaming           bool `json:"server_streaming"`
			}
		}
		Messages map[string]struct {
			Fields []struct {
				Name           string
				JSONName       string `json:"json_name"`
				Number         int
				Type           string
				Cardinality    string
				Proto3Optional bool `json:"proto3_optional"`
				Oneof          *string
			}
			MapEntry bool `json:"map_entry"`
		}
		Enums map[string]struct {
			Values []struct {
				Name   string
				Number int
			}
		}
	}
	if err := json.Unmarshal(data, &catalog); err != nil {
		t.Fatal(err)
	}
	methods, payloads := 0, 0
	for _, s := range catalog.Services {
		for _, m := range s.Methods {
			methods++
			if m.Path != "/"+s.Name+"/"+m.Name {
				t.Errorf("incorrect method path: %s", m.Path)
			}
			if m.Name == "Ping" && m.Input != "oberon.servicegateway.PingRequest" {
				t.Errorf("incorrect Ping input: %s", m.Input)
			}
		}
	}
	if methods != 103 || len(catalog.Messages) != 281 || len(catalog.Enums) != 1 {
		t.Fatalf("catalog counts: methods=%d messages=%d enums=%d", methods, len(catalog.Messages), len(catalog.Enums))
	}
	for _, m := range catalog.Messages {
		for _, f := range m.Fields {
			if f.Name == "json_payload" {
				payloads++
				if f.Number != 2 || f.Type != "string" || f.JSONName != "jsonPayload" {
					t.Errorf("incorrect json_payload: %+v", f)
				}
			}
		}
	}
	if payloads == 0 {
		t.Fatal("json_payload missing")
	}
}
