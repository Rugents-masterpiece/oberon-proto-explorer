package main
import (
    "context"
    "fmt"
    "net"
    "os"
    "strconv"
    "strings"
    "time"

    pb "example.com/oberon-client/pb"
    "google.golang.org/grpc"
    "google.golang.org/grpc/credentials/insecure"
    "google.golang.org/grpc/status"
)

func parseArgs(args []string) (string, int, error) {
    if len(args) == 0 { return "192.168.16.169", 21008, nil }
    if len(args) != 2 || strings.TrimSpace(args[0]) == "" { return "", 0, fmt.Errorf("usage: oberon-ping [host port]") }
    port, err := strconv.Atoi(args[1])
    if err != nil || port < 1 || port > 65535 { return "", 0, fmt.Errorf("port must be 1..65535") }
    return args[0], port, nil
}

func run(args []string) int {
    host, port, err := parseArgs(args)
    if err != nil { fmt.Fprintln(os.Stderr, err); return 2 }
    fmt.Fprintln(os.Stderr, "WARNING: plaintext gRPC; trusted LAN only (no TLS).")
    conn, err := grpc.NewClient(net.JoinHostPort(host, strconv.Itoa(port)), grpc.WithTransportCredentials(insecure.NewCredentials()))
    if err != nil { fmt.Fprintln(os.Stderr, "channel creation failed"); return 1 }
    defer conn.Close()
    ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
    defer cancel()
    response, err := pb.NewOBERONServiceGRPCClient(conn).Ping(ctx, &pb.PingRequest{Message: "hello"})
    if err != nil { fmt.Fprintln(os.Stderr, "Ping failed:", status.Code(err)); return 1 }
    fmt.Println("Ping ->", response.GetMessage())
    return 0
}

func main() { os.Exit(run(os.Args[1:])) }
