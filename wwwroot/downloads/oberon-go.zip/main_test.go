package main
import "testing"
func TestExplicitHostAndPort(t *testing.T) {
    host, port, err := parseArgs([]string{"localhost", "1234"})
    if err != nil || host != "localhost" || port != 1234 { t.Fatalf("got %q %d %v", host, port, err) }
}
func TestRejectsInvalidArgumentsBeforeNetwork(t *testing.T) {
    for _, args := range [][]string{{"host"}, {"", "21008"}, {"host", "0"}, {"host", "65536"}, {"host", "x"}, {"host", "21008", "extra"}} {
        if _, _, err := parseArgs(args); err == nil { t.Errorf("accepted %q", args) }
    }
}
func TestDefaultsWithoutArguments(t *testing.T) {
    host, port, err := parseArgs(nil)
    if err != nil || host != "192.168.16.169" || port != 21008 {
        t.Fatalf("got %q %d %v", host, port, err)
    }
}
