# Overenie natívneho offline exportu – Go

TDD RED: po `sh generate.sh` zlyhal `go test -mod=readonly -run TestOfflineInventoryCommand .` s `native offline inventory command failed: exit status 1` pred vytvorením `cmd/inventory/main.go`.

GREEN: `go test -mod=readonly ./...` → úspešné root aj `cmd/inventory` testy; `pb` nemá testovacie súbory. Dodatočný akceptačný test je pri bežnom behu preskočený, ak nie je nastavený `INVENTORY_REFERENCE`; samostatný plný beh nižšie uspel.

Overené presné príkazy:

```sh
cd /home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/go
export TMPDIR=/home/rugent/.cache/oberon-test-tmp
export PATH=/home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/bin:$PATH
sh generate.sh
go test -mod=readonly ./...
go run ./cmd/inventory > rpc-inventory.json
```

Všetky príkazy skončili kódom 0. JSON bol skutočne zapísaný do `/home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/go/rpc-inventory.json`.

SHA-256: `2613e2d8a46f6f2c35f971c354078a9b0ada58d8298261d1137864f6970755ee`.

Export používa štandardné `encoding/json`; stdout obsahuje iba JSON a chyby idú na stderr.

## Úplná nezávislá kontrola

Go akceptačný test `cmd/inventory/reference_test.go` vytvorí očakávaný katalóg priamo z binárneho `FileDescriptorSet` vytvoreného samostatným protoc, nie z exportovaných runtime objektov. Porovná celý Go runtime katalóg a oba skutočne zapísané JSON súbory: všetky služby/metódy, 281 správ a všetkých 829 polí vrátane JSON názvu, čísla, typu, cardinality, proto3_optional, oneof, map_entry a všetkých hodnôt enumov.

```sh
cd /home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/go
export TMPDIR=/home/rugent/.cache/oberon-test-tmp
/home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/bin/protoc -I proto --descriptor_set_out=reference.pb proto/oberon_service_grpc.proto
INVENTORY_REFERENCE="$PWD/reference.pb" \
JAVA_INVENTORY_JSON=/home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/java/rpc-inventory.json \
GO_INVENTORY_JSON="$PWD/rpc-inventory.json" \
go test -mod=readonly -v ./cmd/inventory
```

Skutočný výsledok:

```text
ALL native outputs equal protoc: methods=103 messages=281 fields=829 enums=1 map_entries=4
--- PASS: TestProtocReferenceAndNativeOutputs
PASS
```

`json_payload` bol samostatne overený: číslo 2, typ `string`, JSON názov `jsonPayload`. Fixture testy overili vnorené správy/enumy, map entry, negatívnu enum hodnotu, explicitný aj syntetický oneof, proto3 optional, proto2 required a obojsmerný streaming.

Použité nástroje: Maven 3.9.9, JDK 25, Go 1.26.0; dostupná cache protoc hlási `libprotoc 25.5` (nie README odporúčaný 29.3). Generovanie aj export fungovali s touto skutočne dostupnou verziou. Export nepoužíva Python, nové závislosti, RPC ani sieťový kanál. Runtime deskriptory neobsahujú zdrojové komentáre; JSON ich zámerne neobsahuje.
