# Overenie natívneho offline exportu – Java

TDD RED: `mvn -q test -Dtest=InventoryTest` zlyhal s `Native offline Inventory exporter is missing` (1 failure, 0 errors) pred vytvorením produkčnej triedy.

GREEN: `mvn test` → `Tests run: 7, Failures: 0, Errors: 0, Skipped: 0`, `BUILD SUCCESS`.

Overené presné príkazy:

```sh
cd /home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/java
export JAVA_HOME=/tmp/oberon-jdk-deb/root/usr/lib/jvm/java-25-openjdk-amd64
export PATH="$JAVA_HOME/bin:/tmp/apache-maven-3.9.9/bin:$PATH"
export TMPDIR=/home/rugent/.cache/oberon-test-tmp
mvn test
mvn exec:java -Dexec.mainClass=example.Inventory -Dexec.args=rpc-inventory.json
mvn -q compile exec:java -Dexec.mainClass=example.Inventory -Dexec.args=rpc-inventory.json
```

Oba exportné príkazy skončili kódom 0. `pom.xml` zachová predvolený `example.Client`, ale hlavná trieda je teraz nastaviteľná cez `${exec.mainClass}`; export nevyvolal Ping. JSON bol skutočne zapísaný do `/home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/java/rpc-inventory.json`.

SHA-256: `ae11bbf2464c69a3affe288845063860750d7b07e8c3f6f9a00b46f80f4254f7`.

JDK 25 vypisuje upozornenia existujúcich Maven/protobuf závislostí na native access a deprecated Unsafe; testy aj export uspeli. Java používa malý JSON serializer bez nových závislostí; escaping riadiacich znakov, úvodzoviek, backslash a Unicode je testovaný.

## Úplná nezávislá kontrola

Go akceptačný test `cmd/inventory/reference_test.go` vytvorí očakávaný katalóg priamo z binárneho `FileDescriptorSet` vytvoreného samostatným protoc, nie z exportovaných runtime objektov. Porovná celý Go runtime katalóg a oba skutočne zapísané JSON súbory: všetky služby/metódy, 281 správ a všetkých 829 polí vrátane JSON názvu, čísla, typu, cardinality, proto3_optional, oneof, map_entry a všetkých hodnôt enumov.

```sh
cd /home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/go
export TMPDIR=/home/rugent/.cache/oberon-test-tmp
/home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/bin/protoc -I proto --descriptor_set_out=reference.pb proto/oberon_service_grpc.proto
INVENTORY_REFERENCE="$PWD/reference.pb" \
JAVA_INVENTORY_JSON=/home/rugent/.cache/oberon-test-tmp/native-export.qsdhEN/java/rpc-inventory.json \
GO_INVENTORY_JSON="$PWD/rpc-inventory.json" \
go test -mod=readonly -v ./cmd/inventory
```

Skutočný výsledok:

```text
ALL native outputs equal protoc: methods=103 messages=281 fields=829 enums=1 map_entries=4
--- PASS: TestProtocReferenceAndNativeOutputs
PASS
```

`json_payload` bol samostatne overený: číslo 2, typ `string`, JSON názov `jsonPayload`. Fixture testy overili vnorené správy/enumy, map entry, negatívnu enum hodnotu, explicitný aj syntetický oneof, proto3 optional, proto2 required a obojsmerný streaming.

Použité nástroje: Maven 3.9.9, JDK 25, Go 1.26.0; dostupná cache protoc hlási `libprotoc 25.5` (nie README odporúčaný 29.3). Generovanie aj export fungovali s touto skutočne dostupnou verziou. Export nepoužíva Python, nové závislosti, RPC ani sieťový kanál. Runtime deskriptory neobsahujú zdrojové komentáre; JSON ich zámerne neobsahuje.
