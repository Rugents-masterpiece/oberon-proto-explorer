package example;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import java.util.concurrent.TimeUnit;
import oberon.servicegateway.OberonServiceGrpc.PingRequest;
import oberon.servicegateway.OBERONServiceGRPCGrpc;

public final class Client {
    record Endpoint(String host, int port) {}
    static Endpoint parseArgs(String[] args) {
        if (args.length == 0) return new Endpoint("192.168.16.169", 21008);
        if (args.length != 2 || args[0].isBlank())
            throw new IllegalArgumentException("Usage: Client [host port]");
        int port = Integer.parseInt(args[1]);
        if (port < 1 || port > 65535) throw new IllegalArgumentException("Port must be 1..65535");
        return new Endpoint(args[0], port);
    }

    public static void main(String[] args) {
        Endpoint endpoint;
        try { endpoint = parseArgs(args); }
        catch (IllegalArgumentException ex) {
            System.err.println(ex.getMessage());
            System.exit(2);
            return;
        }
        System.err.println("WARNING: plaintext gRPC; trusted LAN only (no TLS).");
        ManagedChannel channel = ManagedChannelBuilder.forAddress(endpoint.host(), endpoint.port()).usePlaintext().build();
        int exitCode = 0;
        try {
            var response = OBERONServiceGRPCGrpc.newBlockingStub(channel)
                .withDeadlineAfter(10, TimeUnit.SECONDS)
                .ping(PingRequest.newBuilder().setMessage("hello").build());
            System.out.println("Ping -> " + response.getMessage());
        } catch (StatusRuntimeException ex) {
            System.err.println("Ping failed: " + ex.getStatus().getCode());
            exitCode = 1;
        } finally {
            channel.shutdownNow();
            try { channel.awaitTermination(5, TimeUnit.SECONDS); }
            catch (InterruptedException ex) { Thread.currentThread().interrupt(); exitCode = 1; }
        }
        if (exitCode != 0) System.exit(exitCode);
    }
}
