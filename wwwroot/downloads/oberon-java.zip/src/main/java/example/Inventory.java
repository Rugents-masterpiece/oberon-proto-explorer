package example;

import com.google.protobuf.Descriptors.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import oberon.servicegateway.OberonServiceGrpc;

/** Offline catalog from generated runtime descriptors; no source comments or RPC calls. */
public final class Inventory {
    private Inventory() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 1 || args[0].isBlank())
            throw new IllegalArgumentException("Usage: Inventory output.json");
        Files.writeString(Path.of(args[0]), json(catalog(OberonServiceGrpc.getDescriptor())) + "\n", StandardCharsets.UTF_8);
    }

    static Map<String, Object> catalog(FileDescriptor file) {
        List<Object> services = new ArrayList<>();
        Map<String, Object> messages = new TreeMap<>(), enums = new TreeMap<>();
        for (ServiceDescriptor service : file.getServices()) {
            List<Object> methods = new ArrayList<>();
            for (MethodDescriptor method : service.getMethods())
                methods.add(object("name", method.getName(), "path", "/" + service.getFullName() + "/" + method.getName(),
                    "input", method.getInputType().getFullName(), "output", method.getOutputType().getFullName(),
                    "client_streaming", method.isClientStreaming(), "server_streaming", method.isServerStreaming()));
            services.add(object("name", service.getFullName(), "methods", methods));
        }
        for (Descriptor message : file.getMessageTypes()) message(message, messages, enums);
        for (EnumDescriptor e : file.getEnumTypes()) enumeration(e, enums);
        return object("services", services, "messages", messages, "enums", enums);
    }

    private static void message(Descriptor message, Map<String, Object> messages, Map<String, Object> enums) {
        List<Object> fields = new ArrayList<>();
        for (FieldDescriptor f : message.getFields()) {
            String type = switch (f.getJavaType()) {
                case MESSAGE -> f.getMessageType().getFullName();
                case ENUM -> f.getEnumType().getFullName();
                default -> f.getType().name().toLowerCase(Locale.ROOT);
            };
            fields.add(object("name", f.getName(), "json_name", f.getJsonName(), "number", f.getNumber(), "type", type,
                "cardinality", f.isRepeated() ? "repeated" : f.isRequired() ? "required" : "optional",
                "proto3_optional", f.toProto().getProto3Optional(),
                "oneof", f.getContainingOneof() == null ? null : f.getContainingOneof().getName()));
        }
        messages.put(message.getFullName(), object("fields", fields, "map_entry", message.getOptions().getMapEntry()));
        for (Descriptor nested : message.getNestedTypes()) message(nested, messages, enums);
        for (EnumDescriptor e : message.getEnumTypes()) enumeration(e, enums);
    }

    private static void enumeration(EnumDescriptor e, Map<String, Object> enums) {
        List<Object> values = new ArrayList<>();
        for (EnumValueDescriptor value : e.getValues()) values.add(object("name", value.getName(), "number", value.getNumber()));
        enums.put(e.getFullName(), object("values", values));
    }

    private static Map<String, Object> object(Object... pairs) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) result.put((String) pairs[i], pairs[i + 1]);
        return result;
    }

    // Only JSON-compatible values constructed above are accepted; strings are escaped as JSON, not Java.
    static String json(Object value) {
        if (value == null) return "null";
        if (value instanceof String text) {
            StringBuilder out = new StringBuilder("\"");
            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                switch (c) {
                    case '"' -> out.append("\\\"");
                    case '\\' -> out.append("\\\\");
                    case '\b' -> out.append("\\b");
                    case '\f' -> out.append("\\f");
                    case '\n' -> out.append("\\n");
                    case '\r' -> out.append("\\r");
                    case '\t' -> out.append("\\t");
                    default -> { if (c < 0x20 || Character.isSurrogate(c)) out.append(String.format(Locale.ROOT, "\\u%04x", (int)c)); else out.append(c); }
                }
            }
            return out.append('"').toString();
        }
        if (value instanceof Boolean || value instanceof Integer) return value.toString();
        if (value instanceof Map<?, ?> map) {
            StringJoiner out = new StringJoiner(",", "{", "}");
            map.forEach((key, item) -> out.add(json(key) + ":" + json(item)));
            return out.toString();
        }
        if (value instanceof List<?> list) {
            StringJoiner out = new StringJoiner(",", "[", "]");
            list.forEach(item -> out.add(json(item)));
            return out.toString();
        }
        throw new IllegalArgumentException("Unsupported JSON value: " + value.getClass());
    }
}
