package example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class ClientTest {
    @Test void explicitHostAndPort() {
        assertEquals(new Client.Endpoint("localhost", 1234), Client.parseArgs(new String[]{"localhost", "1234"}));
    }
    @Test void rejectsInvalidArgumentsBeforeNetwork() {
        for (String[] args : new String[][]{{"host"}, {"", "21008"}, {"host", "0"}, {"host", "65536"}, {"host", "x"}, {"host", "21008", "extra"}}) {
            assertThrows(IllegalArgumentException.class, () -> Client.parseArgs(args));
        }
    }
    @Test void defaultsWithoutArguments() {
        var endpoint = Client.parseArgs(new String[0]);
        assertEquals("192.168.16.169", endpoint.host());
        assertEquals(21008, endpoint.port());
    }
}
