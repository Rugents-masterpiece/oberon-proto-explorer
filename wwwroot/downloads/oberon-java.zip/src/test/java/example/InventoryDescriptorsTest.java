package example;

import com.google.protobuf.DescriptorProtos.FileDescriptorProto;
import com.google.protobuf.Descriptors.FileDescriptor;
import com.google.protobuf.TextFormat;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryDescriptorsTest {
    @Test @SuppressWarnings("unchecked") void nestedDescriptorsPresenceAndStreaming() throws Exception {
        var proto = FileDescriptorProto.newBuilder();
        TextFormat.merge("""
            name:"fixture.proto" package:"fixture" syntax:"proto3"
            message_type { name:"Outer"
              oneof_decl {name:"choice"} oneof_decl {name:"_optional_text"}
              field {name:"text" number:1 type:TYPE_STRING label:LABEL_OPTIONAL oneof_index:0}
              field {name:"optional_text" number:2 type:TYPE_STRING label:LABEL_OPTIONAL oneof_index:1 proto3_optional:true}
              field {name:"entries" number:3 type:TYPE_MESSAGE type_name:".fixture.Outer.EntriesEntry" label:LABEL_REPEATED}
              field {name:"state" number:4 type:TYPE_ENUM type_name:".fixture.Outer.State" label:LABEL_OPTIONAL}
              nested_type {name:"EntriesEntry" options {map_entry:true}
                field {name:"key" number:1 type:TYPE_STRING label:LABEL_OPTIONAL}
                field {name:"value" number:2 type:TYPE_INT64 label:LABEL_OPTIONAL}}
              enum_type {name:"State" value {name:"UNKNOWN" number:0} value {name:"NEGATIVE" number:-1}}
            }
            service {name:"Stream" method {name:"Chat" input_type:".fixture.Outer" output_type:".fixture.Outer" client_streaming:true server_streaming:true}}
            """, proto);
        var c = Inventory.catalog(FileDescriptor.buildFrom(proto.build(), new FileDescriptor[0]));
        var messages = (Map<String, Map<String,Object>>) c.get("messages");
        assertEquals(2, messages.size());
        assertEquals(true, messages.get("fixture.Outer.EntriesEntry").get("map_entry"));
        var fields = (List<Map<String,Object>>) messages.get("fixture.Outer").get("fields");
        assertEquals("choice", fields.get(0).get("oneof"));
        assertEquals(false, fields.get(0).get("proto3_optional"));
        assertEquals("_optional_text", fields.get(1).get("oneof"));
        assertEquals(true, fields.get(1).get("proto3_optional"));
        assertEquals("optionalText", fields.get(1).get("json_name"));
        assertEquals("fixture.Outer.EntriesEntry", fields.get(2).get("type"));
        assertEquals("repeated", fields.get(2).get("cardinality"));
        assertNull(fields.get(2).get("oneof"));
        assertEquals("fixture.Outer.State", fields.get(3).get("type"));
        var enums = (Map<String,Map<String,Object>>) c.get("enums");
        assertEquals(-1, ((List<Map<String,Object>>) enums.get("fixture.Outer.State").get("values")).get(1).get("number"));
        var services = (List<Map<String,Object>>) c.get("services");
        var method = ((List<Map<String,Object>>) services.get(0).get("methods")).get(0);
        assertEquals("/fixture.Stream/Chat", method.get("path"));
        assertEquals(true, method.get("client_streaming"));
        assertEquals(true, method.get("server_streaming"));
    }

    @Test @SuppressWarnings("unchecked") void proto2Required() throws Exception {
        var proto = FileDescriptorProto.newBuilder();
        TextFormat.merge("""
            name:"required.proto" package:"fixture" syntax:"proto2"
            message_type {name:"Required" field {name:"id" number:1 type:TYPE_INT64 label:LABEL_REQUIRED}}
            """, proto);
        var c = Inventory.catalog(FileDescriptor.buildFrom(proto.build(), new FileDescriptor[0]));
        var messages = (Map<String,Map<String,Object>>) c.get("messages");
        var field = ((List<Map<String,Object>>) messages.get("fixture.Required").get("fields")).get(0);
        assertEquals("required", field.get("cardinality"));
        assertEquals("int64", field.get("type"));
        assertEquals(false, field.get("proto3_optional"));
    }

    @Test void jsonEscapingAndInvalidArguments() {
        assertEquals("\"\\\"\\\\\\b\\f\\n\\r\\t\\u0001é\\ud83d\\ude00\"", Inventory.json("\"\\\b\f\n\r\t\u0001é😀"));
        assertEquals("null", Inventory.json(null));
        assertThrows(IllegalArgumentException.class, () -> Inventory.json(new Object()));
        for (String[] args : new String[][]{{}, {""}, {"a", "b"}})
            assertThrows(IllegalArgumentException.class, () -> Inventory.main(args));
    }
}
