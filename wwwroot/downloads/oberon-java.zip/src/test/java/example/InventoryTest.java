package example;

import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import oberon.servicegateway.OberonServiceGrpc;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {
    @Test @SuppressWarnings("unchecked") void exportsGeneratedCatalogWithoutNetwork() throws Exception {
        Class<?> exporter;
        try { exporter = Class.forName("example.Inventory"); }
        catch (ClassNotFoundException ex) { fail("Native offline Inventory exporter is missing"); return; }
        var method = exporter.getDeclaredMethod("catalog", com.google.protobuf.Descriptors.FileDescriptor.class);
        method.setAccessible(true);
        var catalog = (Map<String, Object>) method.invoke(null, OberonServiceGrpc.getDescriptor());
        assertEquals(3, catalog.size());
        var services = (List<Map<String, Object>>) catalog.get("services");
        assertEquals(103, services.stream().mapToInt(s -> ((List<?>) s.get("methods")).size()).sum());
        var messages = (Map<String, Map<String, Object>>) catalog.get("messages");
        assertEquals(281, messages.size());
        assertEquals(1, ((Map<?, ?>) catalog.get("enums")).size());
        var payloads = messages.values().stream().flatMap(m -> ((List<Map<String,Object>>) m.get("fields")).stream()).filter(f -> f.get("name").equals("json_payload")).toList();
        assertFalse(payloads.isEmpty());
        for (var f : payloads) {
            assertEquals(2, f.get("number"));
            assertEquals("string", f.get("type"));
            assertEquals("jsonPayload", f.get("json_name"));
        }
        var methods = (List<Map<String,Object>>) services.get(0).get("methods");
        var ping = methods.stream().filter(m -> m.get("name").equals("Ping")).findFirst().orElseThrow();
        assertEquals("/oberon.servicegateway.OBERONServiceGRPC/Ping", ping.get("path"));
        assertEquals("oberon.servicegateway.PingRequest", ping.get("input"));
        var output = Files.createTempFile("inventory-", ".json");
        try {
            exporter.getMethod("main", String[].class).invoke(null, (Object) new String[]{output.toString()});
            String json = Files.readString(output);
            assertTrue(json.startsWith("{"));
            assertTrue(json.contains("\"json_name\":\"jsonPayload\""));
            assertFalse(json.contains("comments"));
        } finally { Files.deleteIfExists(output); }
    }
}
