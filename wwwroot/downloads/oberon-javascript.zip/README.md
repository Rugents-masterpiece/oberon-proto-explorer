# OBERON Ping — JavaScript

Samostatný JavaScript klient pre bezpečný test dostupnosti OBERON ServiceGateway pomocou jediného RPC Ping.

## Predpoklady

Node.js 22+ a npm; prístup k serveru cez dôveryhodnú LAN.

Balík musí obsahovať autoritatívny súbor `proto/oberon_service_grpc.proto`; nekopírujte kontrakt zo starých príkladov. Všetky nasledujúce príkazy sú relatívne ku koreňu rozbaleného balíka.

## Inštalácia závislostí

Príkaz spustite v koreňovom priečinku rozbaleného balíka.

```sh
npm install
```

## Dynamický kontrakt a offline testy

@grpc/proto-loader načíta proto/oberon_service_grpc.proto za behu podľa umiestnenia client.js; @grpc/grpc-js vytvorí klienta. Generovanie kódu nie je potrebné. Testy argumentov server nekontaktujú.

```sh
npm test
```

## Offline export RPC a atribútov

Stačí Node.js a npm; `inventory.js` používa deklarovanú závislosť `protobufjs`.
Načíta pôvodný proto s `keepCase`, vyrieši odkazy na typy a vypíše JSON katalóg
metód, vstupov/výstupov, polí a enum hodnôt. Nevytvára kanál ani nevolá server.
Export zdrojové komentáre neobsahuje.

```sh
npm install
node inventory.js > rpc-inventory.json
```

## Ping

Očakávaná úspešná odpoveď má tvar Ping -> pong. Ide o vysvetlenie, nie o záznam aktuálneho behu.

```sh
node client.js --host 192.168.16.169 --port 21008
```

## Poznámky

- Ide o natívne gRPC cez HTTP/2. Tento klient nie je určený pre prehliadač; prehliadač potrebuje gRPC-Web a kompatibilný server alebo proxy.
- Ukážka používa nešifrované spojenie (plaintext), iba v dôveryhodnej LAN. Mimo nej nakonfigurujte TLS a overovanie certifikátu.
- Ping nevyžaduje prihlásenie. Klient posiela iba Ping, má deadline 10 sekúnd a po skončení zatvorí kanál.
- Pri budúcom rozšírení autentifikácie zavolajte GetLoginSalts s username. Pre dostupné backendy vypočítajte SHA1(salt + password) z bajtov Windows-1250 (cp1250), ako hexadecimálny reťazec. Do LoginUser vložte gen1PasswordHash, gen2PasswordHash a prípadne cashRegisterGen2PasswordHash podľa príslušných saltov. Skontrolujte result; sessionId odošlite v metadata s kľúčom userdata. Tajomstvá a sessionId nelogujte. Táto ukážka autentifikáciu nevykonáva.
- Host zadávajte ako DNS názov alebo IPv4 adresu bez http:// a bez portu; port je samostatné --port číslo 1 až 65535. Predvolené hodnoty sú 192.168.16.169 a 21008.
- Pri opakovanom testovaní ponechajte medzi volaniami aspoň 5 sekúnd. Úspešný Ping neoveruje autentifikáciu ani obchodné operácie.

V balíku nie sú vygenerované moduly, node_modules ani binárne závislosti; vzniknú lokálne počas prípravy.
