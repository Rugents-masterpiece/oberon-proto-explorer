function parseArgs(argv) {
  const options = {host: '192.168.16.169', port: 21008};
  for (let i = 0; i < argv.length; i += 2) {
    const flag = argv[i];
    const value = argv[i + 1];
    if (!['--host', '--port'].includes(flag) || value === undefined)
      throw new Error('Usage: node client.js [--host DNS-or-IPv4] [--port 1..65535]');
    if (flag === '--host') {
      if (!/^[A-Za-z0-9._-]+$/.test(value)) throw new Error('Invalid host (no scheme or port)');
      options.host = value;
    } else {
      if (!/^[0-9]+$/.test(value) || Number(value) < 1 || Number(value) > 65535)
        throw new Error('Port must be an integer from 1 to 65535');
      options.port = Number(value);
    }
  }
  return options;
}

async function main(argv = process.argv.slice(2)) {
  const {host, port} = parseArgs(argv);
  const path = require('node:path');
  const grpc = require('@grpc/grpc-js');
  const loader = require('@grpc/proto-loader');
  const definition = loader.loadSync(path.join(__dirname, 'proto', 'oberon_service_grpc.proto'));
  const service = grpc.loadPackageDefinition(definition).oberon.servicegateway;
  const client = new service.OBERONServiceGRPC(`${host}:${port}`, grpc.credentials.createInsecure());
  try {
    const response = await new Promise((resolve, reject) => {
      client.Ping({message: 'hello'}, {deadline: new Date(Date.now() + 10000)},
        (error, result) => error ? reject(error) : resolve(result));
    });
    console.log(`Ping -> ${response.message}`);
  } finally {
    client.close();
  }
}
module.exports = {parseArgs, main};
if (require.main === module) {
  main().catch(error => {
    console.error(`Error: ${error.details || error.message}`);
    process.exitCode = 1;
  });
}
