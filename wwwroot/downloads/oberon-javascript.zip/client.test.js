const test = require('node:test');
const assert = require('node:assert/strict');
const { parseArgs } = require('./client');
test('defaults', () => {
  assert.deepEqual(parseArgs([]), {host: '192.168.16.169', port: 21008});
});
test('explicit host and port', () => {
  assert.deepEqual(parseArgs(['--host', 'localhost', '--port', '12345']), {host: 'localhost', port: 12345});
});
test('invalid arguments', () => {
  for (const args of [['--port', '0'], ['--port', '65536'], ['--port', '1.5'], ['--host', ''], ['--host', 'http://localhost'], ['--unknown'], ['--port']]) {
    assert.throws(() => parseArgs(args));
  }
});
