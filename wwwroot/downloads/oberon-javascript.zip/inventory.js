// Offline proto parsing with Node.js only; never opens a gRPC channel.
const protobuf = require('protobufjs');
const path = require('node:path');

function inventory(filename = path.join(__dirname, 'proto', 'oberon_service_grpc.proto')) {
  const root = new protobuf.Root().loadSync(filename, { keepCase: true }).resolveAll();
  const result = { services: [], messages: {}, enums: {} };
  const fullName = item => item.fullName.replace(/^\./, '');
  const camelCase = name => name.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
  function fieldType(owner, field) {
    const type = field.resolvedType ? fullName(field.resolvedType) : field.type;
    if (!field.map) return type;
    // protobufjs keeps maps as MapField; protoc represents them as nested entry messages.
    const name = camelCase(field.name);
    const entry = `${fullName(owner)}.${name[0].toUpperCase()}${name.slice(1)}Entry`;
    result.messages[entry] = { map_entry: true, fields: [
      { name: 'key', json_name: 'key', number: 1, type: field.keyType, cardinality: 'optional', proto3_optional: false, oneof: null },
      { name: 'value', json_name: 'value', number: 2, type, cardinality: 'optional', proto3_optional: false, oneof: null }
    ] };
    return entry;
  }
  function visit(item) {
    if (item instanceof protobuf.Type) {
      result.messages[fullName(item)] = {
        map_entry: Boolean(item.options?.map_entry),
        fields: item.fieldsArray.map(field => ({
          name: field.name,
          json_name: field.options?.json_name || camelCase(field.name),
          number: field.id,
          type: fieldType(item, field),
          cardinality: field.repeated || field.map ? 'repeated' : field.required ? 'required' : 'optional',
          proto3_optional: Boolean(field.options?.proto3_optional),
          oneof: field.partOf?.name || null
        }))
      };
    } else if (item instanceof protobuf.Enum) {
      result.enums[fullName(item)] = { values: Object.entries(item.values).map(([name, number]) => ({ name, number })) };
    } else if (item instanceof protobuf.Service) {
      const name = fullName(item);
      result.services.push({ name, methods: item.methodsArray.map(method => ({
        name: method.name, path: `/${name}/${method.name}`,
        input: fullName(method.resolvedRequestType), output: fullName(method.resolvedResponseType),
        client_streaming: Boolean(method.requestStream), server_streaming: Boolean(method.responseStream)
      })) });
    }
    for (const nested of item.nestedArray || []) visit(nested);
  }
  visit(root);
  return result;
}

if (require.main === module) console.log(JSON.stringify(inventory(), null, 2));
module.exports = { inventory };
