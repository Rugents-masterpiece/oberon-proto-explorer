const test = require('node:test');
const assert = require('node:assert/strict');
const { inventory } = require('./inventory');

test('offline export preserves RPCs, maps and optional fields', () => {
  const data = inventory();
  assert.equal(data.services[0].methods.length, 103);
  assert.equal(Object.keys(data.messages).length, 281);
  const payload = data.messages['oberon.servicegateway.G1ProcedureCallRequest'].fields[1];
  assert.equal(payload.name, 'json_payload');
  assert.equal(payload.json_name, 'jsonPayload');
  assert.equal(payload.type, 'string');
  assert.equal(payload.number, 2);
  const target = data.messages['oberon.servicegateway.GetBusinessPartnerRequest'].fields[2];
  assert.equal(target.proto3_optional, true);
  assert.equal(target.oneof, '_target_backend');
  assert.equal(data.messages['oberon.servicegateway.GetCompanySettingsResponse.SettingsEntry'].map_entry, true);
});
