# OBERON Ping — Python

Samostatný Python klient pre bezpečný test dostupnosti OBERON ServiceGateway pomocou jediného RPC Ping.

## Predpoklady

Python 3.10+ s modulom venv a pip; prístup k serveru cez dôveryhodnú LAN.

Balík musí obsahovať autoritatívny súbor `proto/oberon_service_grpc.proto`; nekopírujte kontrakt zo starých príkladov. Všetky nasledujúce príkazy sú relatívne ku koreňu rozbaleného balíka.

## Virtuálne prostredie

Príkazy spúšťajte v koreňovom priečinku rozbaleného balíka.

```sh
python3 -m venv .venv
```

## Inštalácia závislostí

Použite pripnuté verzie. Na Windows nahraďte .venv/bin/python za .venv\Scripts\python.exe.

```sh
.venv/bin/python -m pip install -r requirements.txt
```

## Generovanie klienta

Autoritatívny kontrakt je v proto/. Oba generované Python moduly vzniknú priamo v koreňovom priečinku vedľa client.py.

```sh
.venv/bin/python -m grpc_tools.protoc -I proto --python_out=. --grpc_python_out=. proto/oberon_service_grpc.proto
```

## Offline testy

Testy argumentov nekontaktujú server.

```sh
.venv/bin/python -m unittest -v
```

## Ping

Očakávaná úspešná odpoveď má tvar Ping -> pong. Je to vysvetlenie očakávaného správania, nie záznam aktuálneho behu.

```sh
.venv/bin/python client.py --host 192.168.16.169 --port 21008
```

## Poznámky

- Ide o natívne gRPC cez HTTP/2. Tento klient nie je určený pre prehliadač; prehliadač potrebuje gRPC-Web a kompatibilný server alebo proxy.
- Ukážka používa nešifrované spojenie (plaintext), iba v dôveryhodnej LAN. Mimo nej nakonfigurujte TLS a overovanie certifikátu.
- Ping nevyžaduje prihlásenie. Klient posiela iba Ping, má deadline 10 sekúnd a po skončení zatvorí kanál.
- Pri budúcom rozšírení autentifikácie zavolajte GetLoginSalts s username. Pre dostupné backendy vypočítajte SHA1(salt + password) z bajtov Windows-1250 (cp1250), ako hexadecimálny reťazec. Do LoginUser vložte gen1PasswordHash, gen2PasswordHash a prípadne cashRegisterGen2PasswordHash podľa príslušných saltov. Skontrolujte result; sessionId odošlite v metadata s kľúčom userdata. Tajomstvá a sessionId nelogujte. Táto ukážka autentifikáciu nevykonáva.
- Host zadávajte ako DNS názov alebo IPv4 adresu bez http:// a bez portu; port je samostatné --port číslo 1 až 65535. Predvolené hodnoty sú 192.168.16.169 a 21008.
- Pri opakovanom testovaní ponechajte medzi volaniami aspoň 5 sekúnd. Úspešný Ping neoveruje autentifikáciu ani obchodné operácie.

V balíku nie sú vygenerované moduly, node_modules ani binárne závislosti; vzniknú lokálne počas prípravy.
