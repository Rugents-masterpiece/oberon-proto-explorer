"""Sessionless OBERON Ping, using generated modules beside this file."""
import argparse
import re
import sys


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="OBERON Ping (10-second deadline)")
    parser.add_argument("--host", default="192.168.16.169")
    parser.add_argument("--port", default="21008")
    args = parser.parse_args(argv)
    if not re.fullmatch(r"[A-Za-z0-9._-]+", args.host):
        parser.error("host must be a DNS name or IPv4 address, without scheme or port")
    if not re.fullmatch(r"[0-9]+", args.port) or not 1 <= int(args.port) <= 65535:
        parser.error("port must be an integer from 1 to 65535")
    args.port = int(args.port)
    return args


def main(argv=None):
    args = parse_args(argv)
    import grpc
    import oberon_service_grpc_pb2 as pb
    import oberon_service_grpc_pb2_grpc as services
    try:
        with grpc.insecure_channel(f"{args.host}:{args.port}") as channel:
            client = services.OBERONServiceGRPCStub(channel)
            response = client.Ping(pb.PingRequest(message="hello"), timeout=10)
            print(f"Ping -> {response.message}")
        return 0
    except grpc.RpcError as error:
        print(f"gRPC error: {error.code().name}: {error.details()}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
