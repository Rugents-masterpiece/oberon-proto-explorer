import unittest
import contextlib
import io
from client import parse_args

class ArgumentTests(unittest.TestCase):
    def test_defaults(self):
        args = parse_args([])
        self.assertEqual((args.host, args.port), ("192.168.16.169", 21008))

    def test_explicit_host_port(self):
        args = parse_args(["--host", "localhost", "--port", "12345"])
        self.assertEqual((args.host, args.port), ("localhost", 12345))

    def test_invalid_arguments(self):
        for argv in (["--port", "0"], ["--port", "65536"], ["--port", "1.5"], ["--host", ""], ["--host", "http://localhost"], ["--unknown"], ["--port"]):
            with self.subTest(argv=argv), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                parse_args(argv)

if __name__ == "__main__":
    unittest.main()
